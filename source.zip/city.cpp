#include "city.h"

using namespace std;

namespace lotr {
}