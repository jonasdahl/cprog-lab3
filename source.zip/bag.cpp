#include "bag.h"

using namespace std;

namespace lotr {
}