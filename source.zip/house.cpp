#include "house.h"

using namespace std;

namespace lotr {
}