#include "treasure.h"

using namespace std;

namespace lotr {
}