#include "backpack.h"

using namespace std;

namespace lotr {
}