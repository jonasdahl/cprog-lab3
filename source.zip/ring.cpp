#include "ring.h"

using namespace std;

namespace lotr {
}