#include "elf.h"

using namespace std;

namespace lotr {	
	bool Elf::eat(Object * const object) {
		Object * obj = find_object(object->get_name());
		if (obj == nullptr)
			return false;
		if (obj->healing_effect() < 0) { 
			cout << object->get_name() << " var gift men eftersom du är en alv" 
				<< " så upptäckte du det innan du hann äta." << endl;
			return false;
		}
		return Character::eat(object);
	}
}