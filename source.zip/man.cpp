#include "man.h"

using namespace std;

namespace lotr {
}