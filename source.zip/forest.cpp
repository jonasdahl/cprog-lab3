#include "forest.h"

using namespace std;

namespace lotr {
}