#include "mine.h"

using namespace std;

namespace lotr {
}