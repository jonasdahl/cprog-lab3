#ifndef ROHIRRIM
#define ROHIRRIM

#include "char.h"
#include "man.h"

#include <list>
#include <map>
#include <iostream>

using namespace std;

namespace lotr {
	class Rohirrim : public Man {
	public:
		Rohirrim(string const & c_name) : Man(c_name) {}
		Rohirrim(string const & c_name, string const & p_name) : Man(c_name, p_name) {}
		virtual string type() const override { return "Rohirrim"; }
		virtual string description() const override { return "Rohirrim är en person från riket Rohan."; }
		bool eat(Object * const object);
	};
}

#endif