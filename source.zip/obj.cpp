#include "obj.h"

using namespace std;

namespace lotr {
	Object::~Object() {

	}
	
	bool Object::operator==(Object const * o) const {
		return name == o->get_name();
	}

	// Sends iCal to std out.
	std::ostream& operator<<(std::ostream & stream, const Object * object) { 
		stream << object->to_string();
	  	return stream;
	}
}