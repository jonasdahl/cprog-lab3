#include "quiver.h"

using namespace std;

namespace lotr {
}