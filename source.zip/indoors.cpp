#include "indoors.h"

using namespace std;

namespace lotr {
}