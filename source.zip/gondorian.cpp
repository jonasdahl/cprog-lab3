#include "gondorian.h"

using namespace std;

namespace lotr {
}