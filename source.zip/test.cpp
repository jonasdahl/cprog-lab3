#include "includes.h"

using namespace std;
using namespace lotr;

int main() {
	Game game;
	game.play();
}
