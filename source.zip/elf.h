#ifndef ELF
#define ELF

#include "char.h"

#include <list>
#include <map>
#include <iostream>

using namespace std;

namespace lotr {
	class Elf : public Character {
	public:
		Elf(string const & c_name) : Character(c_name) {}
		Elf(string const & c_name, string const & p_name) : Character(c_name, p_name) {}
		virtual string type() const { return "Alv"; }
		virtual string description() const override { return "Alv"; }
		virtual bool eat(Object * const object);
	};
}

#endif