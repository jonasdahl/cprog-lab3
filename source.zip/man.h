#ifndef MAN
#define MAN

#include "char.h"

#include <list>
#include <map>
#include <iostream>

using namespace std;

namespace lotr {
	class Man : public Character {
	public:
		Man(string const & c_name) : Character(c_name) { health = max_health = 20; }
		Man(string const & c_name, string const & p_name) : Character(c_name, p_name) { health = max_health = 20; }
		virtual string type() const = 0;
	};
}

#endif